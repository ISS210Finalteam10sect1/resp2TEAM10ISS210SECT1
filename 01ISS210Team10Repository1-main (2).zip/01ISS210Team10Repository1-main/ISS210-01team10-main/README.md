# ISS210FinalTemplate
  "Teach Peace"Upham, Becky, et al. “Young People Who Experience Frequent Discrimination More Likely to Have Behavioral and Mental Problems.” EverydayHealth.com, 11 Nov. 2021, https://www.everydayhealth.com/emotional-health/young-people-who-experience-frequent-discrimination-more-likely-to-have-behavioral-and-mental-problems/.
<p></p>
Article-“How economic inequality shapes social class stereotyping”. Journal of Experimental Social Psychology, Volume 98, (2022). https://www.sciencedirect.com/science/article/pii/S0022103121001517?via%3Dihub
https://youtu.be/vF5M9Oeqbis stereotyping in society with medias impact
Olesen, Jacob. “Genders and Colors - Why Is Pink for Girls and Blue for Boys?” Color-Meanings.com, 16 Oct. 2014, www.color-meanings.com/genders-and-colors-why-is-pink-for-girls-and-blue-for-boys/. Accessed 5 Dec. 2022.
https://static.vecteezy.com/system/resources/previews/002/896/742/original/sad-boy-depressed-boy-looking-lonely-free-vector.jpg "Stereotypes about overweight students and their impact on grading among physical education teachers"


